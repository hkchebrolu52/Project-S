package Academy;

import java.io.IOException;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import Resources.base;
import junit.framework.Assert;
import pageObjects.LandingPage;

public class ValidateTitle extends base{
	public static Logger log=LogManager.getLogger(base.class.getName());
	@BeforeTest
	public void initialize() throws IOException {
		driver=InitializeDriver();
		log.info("Driver is Intialized");
		driver.manage().window().maximize();
		driver.get(prop.getProperty("url"));
		log.info("Naviagted to HomePage");
	}

	@Test
	public void validateTitle() throws IOException {
		
		
		LandingPage l=new LandingPage(driver);
		Assert.assertEquals( l.getTitle().getText(),"FEATURED 123 COURSES");
		log.info("Validated Text Message");
		}
	@AfterClass
	public void tearDown() {
		driver.close();
		driver=null;
	}
	
}
