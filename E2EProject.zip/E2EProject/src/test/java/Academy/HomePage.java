package Academy;

import java.io.IOException;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.JavascriptExecutor;
import org.testng.annotations.AfterTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import Resources.base;
import pageObjects.LandingPage;
import pageObjects.LoginPage;

public class HomePage extends base{
	
	
	public static Logger log=LogManager.getLogger(base.class.getName());
	@Test(dataProvider="getData")
	public void basePageNavigation(String username,String password,String text) throws IOException {
		driver=InitializeDriver();
		
		driver.manage().window().maximize();
		driver.get(prop.getProperty("url"));
		LandingPage l=new LandingPage(driver);
		((JavascriptExecutor) driver).executeScript("window.confirm = function(msg) { return flase; }");
		l.getLogin().click();
		
		LoginPage login=new LoginPage(driver);
		login.getEmail().sendKeys(username);
		login.getPassword().sendKeys(password);
		login.clickLogin().click();
		log.info(text);
		driver.close();
		
		}
	@DataProvider
	public Object[][] getData() {
		Object[][] data=new Object[2][3];
		
		//1st row
		data[0][0]="restricteduser@gmail.com";
		data[0][1]="India@123";
		data[0][2]="Restricted";
		
		//2nd Row
		data[1][0]="nonrestrictedUser@gmail.com";
		data[1][1]="India@123";
		data[1][2]="Non-Restricted";
		return data;
	}
	
	
}
