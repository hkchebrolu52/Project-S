package pageObjects;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class LandingPage {
 public WebDriver driver;
 
 By signin=By.xpath("//a[@href='http://qaclickacademy.usefedora.com/sign_in']");
 By title=By.cssSelector(".text-center>h2");
 By contact=By.xpath("//a[@href='contact.php']");
 
 public LandingPage(WebDriver driver) {
	// TODO Auto-generated constructor stub
	 this.driver=driver;
}

public WebElement getLogin() {
	
	
	return driver.findElement(signin);
		
	}
public WebElement getTitle() {
	
	
	return driver.findElement(title);
		
	}
public WebElement getContactIsDisplayed() {
	
	
	return driver.findElement(contact);
		
	}
	 
 }

